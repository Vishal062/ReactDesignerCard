import "./styles.css";
import { Pizza } from "./Components/pizzamenu";
export default function App() {
  return (
    <div className="item">
      <Pizza />
    </div>
  );
}
